const User = require("./user");

class Claim {
    constructor(id, claimName){
        this.id = id;
        user = User;
        this.claimName = claimName;
    }
}

module.exports = Claim