const User = require("./user");

class Claim {
    constructor(id, claimName){
        this.id = id;
        user = User;
        this.claim = claimName;
    }
}

module.exports = Claim